package cardGames; /**
 * 
 */

public class Card {

	public static final int HEARTS = 0;
	public static final int CLUBS = 1;
	public static final int SPADES = 2;
	public static final int DIAMONDS = 3;

	private int suit;
	private int value;
	
	//Creating constants that will store the values for the corresponding numbers
	private final String suitKey = "HCSD";
	
	private final String[] valueKey = {"A", "2", "3", "4", "5", "6", "7", "8", "9,", "10", "J", "Q", "K"};
	
	/**
	 * @param suit
	 * @param value
	 */
	public Card(int suit, int value) {
		this.suit = suit;
		this.value = value;
	}

	/**
	 * Represent the card as string for printing Now the cardGames.Card can be printed with
	 * println
	 */
	public String toString() {
		
		String Value = getValueString();
		char Suit = getSuitString();
		return  Suit + " "+Value;
	}

	/**
	 * @return the value
	 */
	public String getValueString() {
		
		return valueKey[value-1];
	
	}

	/**
	 * @return the suit
	 */
	public char getSuitString() {
		
		char Suit = suitKey.charAt(suit);
		return Suit;
		
	}
	
	public int getSuit() {
		return suit;
	}
	
	public int getValue() {
		return value;
	}

}
