package cardGames; /**
 * 
 */

public class Hand {
	private Card[] hand;
	private int Capacity =0;  //Num of cards hand can hold
	private int numCards = 0;
	
	//creates a hand to hold 10 cards
	public Hand() {
		
		hand = new Card[10]; //Creates space for 10 cards
		Capacity = 10;
		
	}
	
	//create a hand to hold num cards
	public Hand(int num) {
		
		hand = new Card[num]; //Creates space for num cards
		Capacity = num;
		
	}
	
	//add a card to this hand
	public void addCard(Card card) {
		
		if (numCards < Capacity) { //Checks if I have space in my hand
			hand[numCards] = card;
			numCards ++;
		}
		
		
		
	}

	//remove the card at index i from this hand
	public void removeCard(int i) {
		
		for (int j =i+1; j< numCards; j++) { //Shift elements to the left 
			
			hand[j-1] = hand[j];
		}
		
		//Example if index 4 is selected then index 4 will be written over and 4 --> 5, 5 --> 6
		
		numCards --;
		
		
	}
	
	//return the value of the cards in this hand
	public int value() {
		
		int sum = 0;
		int Value = 0;
		 
		
		for (int i =0; i<numCards; i++) {
			
			Value = hand[i].getValue();
			
			if (Value >10) {//If the value is 11, 12, 13 meaning J, Q, K then the value is 10
				Value = 10;
			}
			
			if ((hand[i].getValueString().equals("A")) && (sum + 11 <= 21)) {//Check if card is ace and if adding 11 will be less than or equal to 21
				Value = 11;
			}
			
			sum = sum+ Value;
			
		}
		
		return sum;
	}
	
}
