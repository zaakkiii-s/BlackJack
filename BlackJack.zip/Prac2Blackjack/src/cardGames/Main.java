package cardGames;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Deck d = new Deck();
        d.shuffle();
        
        Hand Player = new Hand();
        Hand Dealer = new Hand();
        
        Scanner input = new Scanner(System.in);
       
        
        boolean playing = true;
        boolean win = false;
        boolean bust = false;
        
        System.out.println("========================================================");
        System.out.println("-----------------------BLACKJACK-------------------------");
      //Dealing two cards to the dealer and the player.
        Card card1 = d.dealCard();
    	Card card2 = d.dealCard();
    	
    	Player.addCard(card1);
    	Player.addCard(card2);
    	
    	System.out.println("You were dealt cards: \n"+card1.toString()+"\n"+card2.toString());
    	
    	card1 = d.dealCard();
    	card2 = d.dealCard();
    
    	Dealer.addCard(card1);
    	Dealer.addCard(card2);
    	
    	System.out.println("Dealers' Cards: "+card1.toString()+"(Card 2 is hidden)");
    	
    	if (Dealer.value() == 21) {
    		playing = false;
    		win = false;
    		
    	}
    	
    	if (Player.value() == 21) {
    		playing = false;
    		win= true;
    	}
    	
        
        while (playing){
        	
        	if (d.isEmpty()) {
        		d.shuffle();
        	}
        	
        	Card cardTemp;
        	
        	System.out.println();
        	
        	System.out.print("Would you like to stand(S) or hit(H):");
        	String answer = input.nextLine();
        	
        	
        	if (answer.equalsIgnoreCase("S")) {
        		playing = false;
        	}
        	else if (answer.equalsIgnoreCase("H")) {
        		cardTemp = d.dealCard();
        		Player.addCard(cardTemp);
        		
        		System.out.println("You were dealt card: "+cardTemp.toString());
        		
        		if (Player.value() > 21) {
        			bust = true;
        			System.out.println("-------------------BUST--------------------");
        			win = false;
        			playing = false;
        		}
        		else if (Player.value() == 21) {
        			System.out.println("----------------!BLACKJACK!-------------");
        			playing = false;
        			win = true;
        			
        		}
        		
   
        	}
        	        	
        	
        }
        
        if (bust) {
        	System.out.println("==================Dealer wins=====================");
        }
        else {
        
        if (Dealer.value() > Player.value() && Dealer.value() <= 21) {
        	win = false;
        	//System.out.println("=====================HOUSE WINS=========================");
        }
        else if (Dealer.value() <= 17) {
        	
        	System.out.println("Dealer's cards: \n"+card1.toString()+"\n"+card2.toString());
        	
        	
        	
        	while (Dealer.value() <= 17) {
        		
        		if (d.isEmpty()) {
        			d.shuffle();
        		}
        		
        		System.out.println("Dealer draws a card");
        		
        		Card card = d.dealCard();
            	Dealer.addCard(card);
            	System.out.println("card: "+card.toString());
        		
        	}
        	
        	if (Dealer.value() > 21) {
        		System.out.println("Dealer is bust :(");
        		win = true;
        	}
        	
        }
        
        if (Dealer.value() < Player.value() && Player.value() <= 21 ||(Dealer.value() > 21)) {
        	System.out.println("==================YOU WIN===========================");
        	
        }
        else if (Dealer.value() > Player.value() && Dealer.value() <= 21) {
        	System.out.println("==================House wins========================");
        	
        }
        else if (Dealer.value() == Player.value()) {
        	System.out.println("===============TIE====================");
        }
        }
        
        System.out.println("Your points: "+Player.value());
        System.out.println("Dealer's points: "+Dealer.value());
        
        
        
        
        
        
    }
    
  
}
